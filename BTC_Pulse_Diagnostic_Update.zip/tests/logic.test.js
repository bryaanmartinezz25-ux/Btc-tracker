const {test}=require('node:test');
const assert=require('node:assert/strict');
const L=require('../public/logic.js');
const goodK=(up=65)=>({upPercent:up,downPercent:100-up,spreadPercent:2});
const flow=(buy=65,move=.06)=>({full:true,bpct:buy,spct:100-buy,delta:move,n:400,total:20});
function step(s,t,k,f,remain=75000,marketId='KXBTC15M-DEMO'){
  return L.signalStep(s,{marketId,now:t,remain,k,flow:f,quoteFresh:true});
}
test('Coinbase match side is the maker; trade direction is the opposing taker',()=>{
  assert.equal(L.decodeTrade({type:'match',product_id:'BTC-USD',side:'sell',size:'20.0',price:'90000',trade_id:123,time:'2026-11-23T17:05:00Z'}).side,'BUY');
  assert.equal(L.decodeTrade({type:'match',product_id:'BTC-USD',side:'buy',size:'1.1',price:'90000',trade_id:124,time:'2026-11-23T17:05:00Z'}).side,'SELL');
  assert.equal(L.decodeTrade({type:'match',product_id:'ETH-USD',side:'buy',size:'1.1',price:'90000',trade_id:125,time:'2026-11-23T17:05:00Z'}),null);
});
test('Pressure computes volume weighted share, not count of people',()=>{
  const t=Date.now(),trades=[{t:t-110000,side:'BUY',size:20,price:100},{t:t-500,side:'SELL',size:5,price:99}];
  const r=L.pressure(trades,t,120,t-130000,true);
  assert.equal(r.bpct,80);assert.equal(r.spct,20);assert.ok(Math.abs(r.delta+1)<0.000001);assert.equal(r.full,true);
  assert.equal(L.pressure(trades,t,120,t-90000,true).full,false);
});
test('3 independent confirmations create initial UP lock, not one tick',()=>{
  let s=null,r;const t=2000000000000;
  r=step(s,t,goodK(65),flow(65,.06));s=r.state;assert.equal(s.direction,null);
  r=step(s,t+8000,goodK(65),flow(65,.06));s=r.state;assert.equal(s.direction,null);
  r=step(s,t+16000,goodK(65),flow(65,.06));s=r.state;assert.equal(s.direction,'UP');assert.equal(r.event.type,'LOCK');
});
test('Strong opposite pressure warns but cannot flip until opposing Kalshi odds confirm',()=>{
  const t=2000000000000;let s=L.emptySignal('KXBTC15M-DEMO');s.direction='DOWN';s.lockedAt=t-30000;
  const r=step(s,t,goodK(30),flow(75,.08));
  assert.equal(r.state.direction,'DOWN');assert.equal(r.state.warningDir,'UP');assert.equal(r.state.pendingDir,null);
});
test('Confirmed DOWN to UP reversal requires 3 checks and vice versa',()=>{
  const t=2000000000000;let s=L.emptySignal('KXBTC15M-DEMO');s.direction='DOWN';s.lockedAt=t-60000;
  for(let i=0;i<2;i++){const r=step(s,t+i*8000,goodK(57),flow(74,.07));s=r.state;assert.equal(s.direction,'DOWN');}
  let r=step(s,t+16000,goodK(57),flow(74,.07));s=r.state;
  assert.equal(s.direction,'UP');assert.equal(s.flipCount,1);assert.equal(r.event.type,'FLIP');
  // Cannot instantly reverse again: 20-second cooldown.
  r=step(s,t+18000,goodK(38),flow(20,-.1));s=r.state;assert.equal(s.direction,'UP');
  for(let i=0;i<3;i++){r=step(s,t+39000+i*8000,goodK(39),flow(19,-.09));s=r.state;}
  assert.equal(s.direction,'DOWN');assert.equal(s.flipCount,2);
});
test('A short contrary spike cannot flip an existing direction',()=>{
  let s=L.emptySignal('KXBTC15M-DEMO');s.direction='DOWN';const t=2000000000000;
  s=step(s,t,goodK(57),flow(80,.09)).state;
  assert.equal(s.pendingDir,'UP');
  s=step(s,t+8000,goodK(40),flow(25,-.09)).state;
  assert.equal(s.direction,'DOWN');assert.equal(s.pendingDir,null);
});
test('New Kalshi market resets lock and final 15 seconds prevent flips',()=>{
  let s=L.emptySignal('old');s.direction='DOWN';
  const r=step(s,2000000000000,goodK(66),flow(80,.10),70000,'new');
  assert.equal(r.state.marketId,'new');assert.equal(r.state.direction,null);
  let n=L.emptySignal('new');n.direction='DOWN';
  for(let i=0;i<3;i++){n=step(n,2000000000000+i*8000,goodK(60),flow(80,.10),14000,'new').state;}
  assert.equal(n.direction,'DOWN');
});
test('No fabricated signal for incomplete, stale or wide-spread data',()=>{
  let s=L.emptySignal('KXBTC15M-DEMO');
  assert.equal(step(s,2000000000000,{...goodK(),spreadPercent:15},flow()).state.direction,null);
  assert.equal(step(s,2000000000000,goodK(),{...flow(),full:false}).state.direction,null);
  assert.equal(L.signalStep(s,{marketId:s.marketId,now:2000000000000,remain:70000,k:goodK(),flow:flow(),quoteFresh:false}).state.direction,null);
});
test('Earlier initial locks wait for 2 minutes inside the active Kalshi market; late setting waits for final 2m',()=>{
  const start=2000000000000;
  let s=L.emptySignal('new');
  for(let i=0;i<3;i++){
    const r=L.signalStep(s,{marketId:'new',marketStart:start,mode:'early',now:start+30000+i*8000,remain:830000-i*8000,k:goodK(65),flow:flow(65,.09),quoteFresh:true});
    s=r.state;
  }
  assert.equal(s.direction,null);
  s=L.emptySignal('new');
  for(let i=0;i<3;i++){
    const r=L.signalStep(s,{marketId:'new',marketStart:start,mode:'early',now:start+125000+i*8000,remain:775000-i*8000,k:goodK(65),flow:flow(65,.09),quoteFresh:true});
    s=r.state;
  }
  assert.equal(s.direction,'UP');
  s=L.emptySignal('new');
  for(let i=0;i<3;i++)s=L.signalStep(s,{marketId:'new',marketStart:start,mode:'late',now:start+125000+i*8000,remain:775000-i*8000,k:goodK(65),flow:flow(65,.09),quoteFresh:true}).state;
  assert.equal(s.direction,null);
});
