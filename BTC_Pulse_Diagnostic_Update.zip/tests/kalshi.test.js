const {test}=require('node:test');const assert=require('node:assert/strict');
const {findCurrentMarket,quote}=require('../netlify/functions/kalshi.js');
test('Kalshi quote converts dollars to percentages, rejects crossed or absent book',()=>{
  const m={yes_bid_dollars:'0.6200',yes_ask_dollars:'0.6600',no_bid_dollars:'0.3400',no_ask_dollars:'0.3800'};
  assert.equal(quote(m).upPercent,64);assert.equal(quote(m).downPercent,36);assert.equal(quote(m).spreadPercent,4);
  assert.equal(quote({yes_bid_dollars:'0.90',yes_ask_dollars:'0.10',no_bid_dollars:'0.10',no_ask_dollars:'0.90'}),null);
});
test('Current Kalshi market is determined by close time, never future-listed markets',()=>{
  const now=Date.parse('2026-11-23T17:05:00Z');
  const mk=(close,status='open')=>({ticker:'KXBTC15M-EXAMPLE'+close,close_time:new Date(close).toISOString(),status});
  const list=[mk(now+1200000),mk(now+600000),mk(now-6000)];
  assert.equal(findCurrentMarket(list,now),list[1]);
  assert.equal(findCurrentMarket([list[0]],now),null);
});
test('Netlify Kalshi function parses public listing into live percent odds',async()=>{
  const oldFetch=global.fetch,now=Date.now();
  global.fetch=async ()=>({ok:true,json:async()=>({markets:[{
    ticker:'KXBTC15M-MOCK',status:'open',close_time:new Date(now+600000).toISOString(),floor_strike:90250.25,
    yes_bid_dollars:'0.6200',yes_ask_dollars:'0.6600',no_bid_dollars:'0.3400',no_ask_dollars:'0.3800'
  }],cursor:''})});
  try{
    const {handler}=require('../netlify/functions/kalshi.js');const result=await handler();const data=JSON.parse(result.body);
    assert.equal(result.statusCode,200);assert.equal(data.ok,true);assert.equal(data.upPercent,64);assert.equal(data.downPercent,36);assert.equal(data.strike,90250.25);
    assert.equal(data.marketUrl,'https://kalshi.com/markets/kxbtc15m');
  }finally{global.fetch=oldFetch;}
});
